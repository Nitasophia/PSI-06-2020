package com.example.psipsi.retorofit.Pengaduan;

public class Kabupaten {
    String name;

    public Kabupaten(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
