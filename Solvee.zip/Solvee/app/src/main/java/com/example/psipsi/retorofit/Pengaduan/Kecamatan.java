package com.example.psipsi.retorofit.Pengaduan;

public class Kecamatan {
    String name;

    public Kecamatan(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
