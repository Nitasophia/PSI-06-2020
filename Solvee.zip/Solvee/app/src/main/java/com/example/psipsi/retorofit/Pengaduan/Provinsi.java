package com.example.psipsi.retorofit.Pengaduan;

public class Provinsi {
    String name;

    public Provinsi(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
